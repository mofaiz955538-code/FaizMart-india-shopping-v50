# V50 keeps JavaScript/WebView entry points intact.
